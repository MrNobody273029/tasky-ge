Hero Lottie JSON — optional
===============================
თუ გაქვს Lottie JSON, ჩადე აქ `hero_scene.json` სახელით.
თუ არ გაქვს ან პირდაპირ ფაილიდან ხსნი (`file://`), მუშაობს fallback ანიმაციაც,
რომელიც მაინც გაჩვენებს მოძრაობას.

რეკომენდაცია (CORS თავიდან ასაცილებლად): გაუშვი index.html პატარა ლოკალური სერვერით:
- Windows/Mac/Linux: გახსენი ტერმინალი ამ საქაღალდეში და აწერე
  python -m http.server 5500
  შემდეგ ბრაუზერში: http://localhost:5500/index.html
