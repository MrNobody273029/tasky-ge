(function(){
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  gsap.registerPlugin(ScrollTrigger);

  const hero = document.getElementById('hero');
  const steps = [
    { el: '#step-1', start: 0.00, end: 0.24 },
    { el: '#step-2', start: 0.25, end: 0.49 },
    { el: '#step-3', start: 0.50, end: 0.74 },
    { el: '#step-4', start: 0.75, end: 1.00 },
  ];

  function bindStepReveal() {
    steps.forEach(s => {
      ScrollTrigger.create({
        trigger: hero,
        start: 'top top',
        end: 'bottom top+=2000',
        onUpdate: self => {
          const p = self.progress;
          const active = (p >= s.start && p < s.end);
          document.querySelector(s.el)?.classList.toggle('active', active);
        }
      });
    });
  }

  // Main pin
  const DURATION_PX = 2000;

  // Fallback "mini-scene" (pure DOM + GSAP) so that something moves even w/o Lottie JSON
  function bootFallback() {
    const wrap = document.getElementById('lottie');
    ['desk','monitor','person','coin','wallet'].forEach(name => {
      const el = document.createElement('div');
      el.className = 'fbk-item fbk-' + name;
      wrap.appendChild(el);
    });
    const desk = wrap.querySelector('.fbk-desk');
    const monitor = wrap.querySelector('.fbk-monitor');
    const person = wrap.querySelector('.fbk-person');
    const coin = wrap.querySelector('.fbk-coin');
    const wallet = wrap.querySelector('.fbk-wallet');

    const tl = gsap.timeline({paused:true});
    // 1) fill a form (person leans / monitor pulse)
    tl.to(monitor, {scale:1.02, duration:0.4, yoyo:true, repeat:3}, 0.05);
    tl.to(person, {y:-6, duration:0.6, yoyo:true, repeat:1, ease:'sine.inOut'}, 0.1);

    // 2) choose contractor (monitor highlight + person moves closer)
    tl.to(monitor, {background:'#355092', duration:0.8}, '>');
    tl.to(person, {x: 30, duration:0.8, ease:'power1.inOut'}, '<');

    // 3) progress — glow pulse
    tl.to(monitor, {scale:1.06, duration:0.5, yoyo:true, repeat:1, ease:'power1'}, '>');
    tl.to(desk, {background:'#1b274b', duration:0.6}, '<');

    // 4) get paid — coin drops into wallet
    tl.fromTo(coin, {y:-80, opacity:0}, {opacity:1, duration:0.2}, '>');
    tl.to(coin, {y: 160, duration:1.0, ease:'power2.in'}, '>-0.05');
    tl.to(coin, {x: -80, duration:0.8, ease:'power1.inOut'}, '<');
    tl.to(coin, {y: 210, x: -120, duration:0.6, ease:'power1.in'}, '>-0.1');
    tl.to(coin, {opacity:0, duration:0.25}, '>-0.05');
    tl.to(wallet, {scale:1.08, duration:0.25, yoyo:true, repeat:1, ease:'power1.out'}, '<');

    ScrollTrigger.create({
      trigger: hero,
      start: 'top top',
      end: `+=${DURATION_PX}`,
      pin: true,
      scrub: 0.6,
      onUpdate: self => tl.totalProgress(self.progress)
    });

    bindStepReveal();
  }

  if (reduceMotion) {
    ScrollTrigger.create({
      trigger: hero,
      start: 'top top',
      end: `+=${DURATION_PX}`,
      pin: true,
      scrub: false
    });
    bindStepReveal();
    document.querySelector('#step-1')?.classList.add('active');
    return;
  }

  // Try to load Lottie. If it fails (common when opening with file://), run fallback.
  let lottieFailed = false;
  const anim = lottie.loadAnimation({
    container: document.getElementById('lottie'),
    renderer: 'svg',
    loop: false,
    autoplay: false,
    path: 'assets/hero_scene.json' // put your JSON here
  });

  anim.addEventListener('DOMLoaded', () => {
    if (lottieFailed) return; // already in fallback
    const total = Math.max(1, anim.getDuration(true));
    ScrollTrigger.create({
      trigger: hero,
      start: 'top top',
      end: `+=${DURATION_PX}`,
      pin: true,
      scrub: 0.6,
      onUpdate: self => {
        const frame = Math.round(self.progress * (total - 1));
        anim.goToAndStop(frame, true);
      }
    });
    ScrollTrigger.create({
      trigger: hero,
      start: 'top top',
      end: `+=${DURATION_PX}`,
      scrub: true,
      snap: {
        snapTo: (value) => {
          const points = steps.map(s => (s.start + s.end)/2);
          let closest = points[0];
          let dist = Math.abs(value - closest);
          for (let i=1;i<points.length;i++){
            const d = Math.abs(value - points[i]);
            if (d < dist) { dist = d; closest = points[i]; }
          }
          return closest;
        },
        duration: {min: 0.08, max: 0.2},
        ease: 'power1.inOut'
      }
    });
    bindStepReveal();
  });

  anim.addEventListener('data_failed', () => {
    lottieFailed = true;
    console.warn('Lottie JSON ვერ ჩაიტვირთა — ვრთავ fallback ანიმაციას.');
    const lottieBox = document.getElementById('lottie');
    lottieBox.innerHTML = '';
    bootFallback();
  });

})();